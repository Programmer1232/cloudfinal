﻿using System.ComponentModel.DataAnnotations;

namespace LMRetailsWebApp.Models
{
    public class Product
    {
        [Key]
        public int ProductID { get; set; }

        [Required]
        public string ProductName { get; set; }

        public string Category { get; set; }

        [DataType(DataType.Currency)]
        public decimal Price { get; set; }

        public int StockQuantity { get; set; }
    }
}
