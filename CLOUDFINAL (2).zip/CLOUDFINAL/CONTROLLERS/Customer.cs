﻿
using LMRetailsWebApp.Models;
using LMRetailsWebApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace LMRetailsWebApp.Controllers
{
    public class CustomerController : Controller
    {
        private readonly RetailService _retailService = new();

        public ActionResult Index()
        {
            var customers = _retailService.GetAllCustomers();
            return View(customers);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Customer customer)
        {
            if (ModelState.IsValid)
            {
                _retailService.AddCustomer(customer);
                return RedirectToAction("Index");
            }
            return View(customer);
        }
    }
}
