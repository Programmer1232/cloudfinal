﻿using System.Collections.Generic;
using System.Linq;
using LMRetailsWebApp.Models;

namespace LMRetailsWebApp.Services
{
    public class RetailService
    {
        private readonly List<Customer> _customers = new();
        private readonly List<Product> _products = new();
        private readonly List<Order> _orders = new();

        public List<Customer> GetAllCustomers() => _customers;

        public List<Product> GetAllProducts() => _products;

        public List<Order> GetAllOrders() => _orders;

        public void AddCustomer(Customer customer) => _customers.Add(customer);

        public void AddProduct(Product product) => _products.Add(product);

        public void AddOrder(Order order) => _orders.Add(order);
    }
}
